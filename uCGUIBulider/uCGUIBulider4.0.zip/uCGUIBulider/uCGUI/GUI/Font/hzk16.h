/**
  ******************************************************************************
  * @file    HZK16.H
  * @author  
  * @version 
  * @date   
  * @brief   
  ******************************************************************************

  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HZK16_H
#define __HZK16_H

/* Includes ------------------------------------------------------------------*/
#include "GUI.H"


extern const GUI_FONT GUI_FontHZ16;


#endif /* __FHZK12GUI_H */